## You should not store plain text credentials within scripts, connect the script to your secure pasword manager or at the very least, encrypt the credentials
$param_vcsa_hostname = "******"
$param_vcsa_username = "******"
$param_vcsa_password = "******"

$param_vrops_hostname = "******"
$param_vrops_username = "******"
$param_vrops_password = "******"

##  Ignore self-signed certificates
add-type @"
    using System.Net;
    using System.Security.Cryptography.X509Certificates;
    public class TrustAllCertsPolicy : ICertificatePolicy {
        public bool CheckValidationResult(
            ServicePoint srvPoint, X509Certificate certificate,
            WebRequest request, int certificateProblem) {
            return true;
        }
    }
"@
[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy

## Create credential from vrops username and password
$vrops_credential_password = ConvertTo-SecureString $param_vrops_password -AsPlainText -Force
$vrops_credential = New-Object PSCredential ($param_vrops_username, $vrops_credential_password)

## Connect to VCSA and vROps
Connect-VIServer -Server $param_vcsa_hostname -User $param_vcsa_username -Password $param_vcsa_password
Connect-OMServer -Server $param_vrops_hostname -Credential $vrops_credential

## vROps date
[DateTime] $date_now = (Get-date)
[int64] $date_now_epoch = Get-Date -Date $date_now.ToUniversalTime() -UFormat %s
$date_now_epoch = $date_now_epoch*1000

## Event variables Change as required
$vcsa_event_start_filter = (Get-Date).AddDays(-2); ## Change the number of days to go back through the events, searching for snapshot creation entries by the specified user account
$backup_system_username = "******" ## Change to the backup service account which creates the snapshot
$vcsa_task_message_filter = "Task: Create virtual machine snapshot" ## Change if you want to focus on another event description field
$event_samples = 500 ##S et the maximum number of events to search for the message filter, per VM. Lower is faster but might miss some events
$vms_in_scope = Get-VM ## Use this variable to limit which VMs are in scope. The default will scan all VMs and may take some time. Consider using a condition to only look at VMs in a particular folder, cluster or that have a tag

## Loop VMs in scope and check for all create snapshot tasks created by backup server user
$vm_backup_statuses = @()

Foreach ($vm in $vms_in_scope){
    $vrops_id = Get-OMResource -Entity $vm

    $tasks = Get-VIEvent -Start $vcsa_event_start_filter -Entity $vm.name -UserName $backup_system_username -MaxSamples $event_samples | Where-Object {$_.FullFormattedMessage -eq $vcsa_task_message_filter} | Select-Object CreatedTime, UserName, FullFormattedMessage
    
    if (!$tasks){
        $task_create_time = ""
        continue 
    }
    else{
        $task_create_time = $tasks[0].CreatedTime
    }

    $task_info = "" | Select-Object vm, vrops_id, last_backup_snapshot_date_time
    $task_info.vm = $vm.Name
    $task_info.vrops_id = $vrops_id.ExtensionData.Identifier
    $task_info.last_backup_snapshot_date_time = $task_create_time

    $vm_backup_statuses+= $task_info
}

$vm_backup_statuses | Out-GridView

## Disconnect from VCSA and vROps
Disconnect-VIServer -Server $param_vcsa_hostname -Force -Confirm:$false
Disconnect-OMServer -Server $param_vrops_hostname -Force -Confirm:$false

## Authenicate to vROPs REST API
$rest_url_authenticate = "https://" + $param_vrops_hostname + "/suite-api/api/auth/token/acquire"

$json_authentication =
"{
 ""username"": ""$param_vrops_username"",
 ""password"": ""$param_vrops_password""
}"

Try {
   $rest_authenticate = Invoke-RestMethod -Method POST -Uri $rest_url_authenticate -Body $json_authentication -ContentType "application/json"
}
Catch {
   Write-Host "Unable to authenticate to vROps REST API" 
   $_.Exception.ToString()
   $error[0] | Format-List -Force
   exit
}

## Get Session ID from response top use with requests
$rest_authentication_session_xml = @{"Authorization"="vRealizeOpsToken "+$rest_authenticate.'auth-token'.token
"Accept"="application/xml"}

## Loop the VMs in the backup status array & create XML with data for sending to vROps via API
foreach ($vm_backup_status in $vm_backup_statuses) {

    Write-Host "Working on " $vm_backup_status.vm

    $xml_data = @('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
    <ops:property-contents xmlns:ops="http://webservice.vmware.com/vRealizeOpsMgr/1.0/" xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
        <ops:property-content statKey="Backup|LastBackupSnapshot">
            <ops:timestamps>{0}</ops:timestamps>
            <ops:values>{1}</ops:values>
        </ops:property-content>
    </ops:property-contents>' -f $date_now_epoch, $vm_backup_status.last_backup_snapshot_date_time
    )

    [xml]$post_xml = $xml_data
    $post_uri = 'https://' + $param_vrops_hostname + '/suite-api/api/resources/'+ $vm_backup_status.vrops_id + '/properties'
    $content_type = "application/xml;charset=utf-8"

    ## Invoke the REST API and POST the XML in the body of the request. Use the session ID as found earlier
    Try {
        Invoke-RestMethod -Method POST -Uri $post_uri -Body $post_xml -Headers $rest_authentication_session_xml -ContentType $content_type -Verbose 
     }
     Catch {
        Write-Host "Unable to invoke vROps REST API" 
        $_.Exception.ToString()
        $error[0] | Format-List -Force
        exit
     }

}